# Διαχείριση Πολυκατοικίας — Android Studio Project

## Τι περιλαμβάνει
Η υπάρχουσα εφαρμογή HTML βρίσκεται στο:
`app/src/main/assets/index.html`

Η Android εφαρμογή την ανοίγει τοπικά μέσα σε WebView, χωρίς να απαιτείται σύνδεση στο Internet.

## Δημιουργία APK
1. Εγκατάστησε Android Studio.
2. Άνοιξε τον φάκελο `PolykatoikiaAndroid`.
3. Περίμενε να ολοκληρωθεί το Gradle Sync.
4. Επίλεξε:
   **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
5. Το APK θα δημιουργηθεί περίπου στο:
   `app/build/outputs/apk/debug/app-debug.apk`

## Σημαντικό
Η εφαρμογή χρησιμοποιεί localStorage για τα δεδομένα της, οπότε οι αλλαγές που γίνονται μέσα στην εφαρμογή αποθηκεύονται στη συσκευή.

Το project είναι έτοιμο για Android Studio και δεν χρειάζεται server για να λειτουργήσει.
