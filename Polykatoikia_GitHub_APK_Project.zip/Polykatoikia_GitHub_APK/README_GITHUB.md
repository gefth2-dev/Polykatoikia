# Διαχείριση Πολυκατοικίας — APK χωρίς Android Studio

1. Δημιούργησε ένα νέο GitHub repository.
2. Ανέβασε όλα τα αρχεία του project, μαζί με τον φάκελο `.github`.
3. Πήγαινε **Actions**.
4. Επίλεξε **Build Android APK**.
5. Πάτησε **Run workflow**.
6. Όταν ολοκληρωθεί, άνοιξε το workflow.
7. Στο **Artifacts** κατέβασε το **Polykatoikia-APK**.
8. Αποσυμπίεσε το ZIP και εγκατάστησε το `app-debug.apk` στο Android.

Το APK είναι debug APK για εγκατάσταση στη συσκευή σου.
